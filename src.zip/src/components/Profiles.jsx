const Profiles = () => {
    return (
        <div className="content">
            <img src="https://camo.githubusercontent.com/091354800855a8b1245e815a49175fd99ecefdcb4f8832ba571f718d77387950/68747470733a2f2f6b656e7463646f6464732e636f6d2f696d616765732f6570696372656163742d70726f6d6f2f65722d312e676966" />
            <div className="ava">
                <img src="https://ustaliy.ru/wp-content/uploads/2019/07/20.jpg" />
            </div>
        </div>
    )
};
export default Profiles;