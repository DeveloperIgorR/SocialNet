const Nav = ()=>{
    return(
        <div className="nav">
        <div><a href="#s">Messages</a></div>
        <div><a href="#s">Profiles</a></div>
        <div><a href="#s">Contacts</a></div>
        <div><a href="#s">Settings</a></div>
      </div>
    )
};
export default Nav;