const Header = () => {
    return (
        <div className="header">
            <img src="https://www.trashedgraphics.com/wp-content/uploads/2013/03/vector_fish_logo.jpg" />
        </div>
    )
};
export default Header;